{
    'name': 'Hotel Management',
    'version': '1.0',
    'summary': 'Module for managing hotel operations',
    'description': 'This module allows users to manage clients, rooms, and invoices in a hotel.',
    'category': 'Sales/Hotel',
    'author': 'Your Name',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/hotel.xml',
        'reports/report_sencillo.xml',
        'views/report_sencillo_template.xml'
    ],
    'css': ['static/src/css/style.css'],  # Ruta al archivo CSS
    'demo': [],
    'qweb': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}

