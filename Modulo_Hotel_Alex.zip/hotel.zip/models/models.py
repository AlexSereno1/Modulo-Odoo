# -*- coding: utf-8 -*-

from odoo import api, models, fields

class Cliente(models.Model):
    _name = 'hotel.cliente'
    _description = 'Modelo para gestionar clientes'

    dnicli = fields.Text('DNI Cliente', required=True)
    nomcli = fields.Text('Nombre', required=True)
    apecli = fields.Text('Apellido' )
    telcli = fields.Char('Teléfono',size = 9)
    corrcli = fields.Text('Correo electrónico')

    def name_get(self):
        result = []
        for record in self:
            cliente = f'{record.dnicli}'
            result.append((record.id, cliente))
        return result

class Habitacion(models.Model):
    _name = 'hotel.habitacion'
    _description = 'Modelo para gestionar habitaciones'

    numhab = fields.Integer('Número de habitación', required=True)
    tiphab = fields.Selection([
        ('individual','Individual'),
        ('matrimonio','Matrimonio')
    ],string = 'tipo', required = True)
    image = fields.Image(string='Imagen de la habitacion')
    deschab = fields.Text('Descripción de la habitación')
    prechab = fields.Float('Precio de la habitación', digits=(5, 2))
    
    id_cliente=fields.Many2one('hotel.cliente', string = 'Cliente', required = True)
    dni = fields.Text(string = 'DNI', related = 'id_cliente.dnicli', required = True, readonly = True)
    nombre = fields.Text(string='Nombre Cliente', related='id_cliente.nomcli', required=True)
    apellido = fields.Text(string='Apellido Cliente', related='id_cliente.apecli', required=True)

    def name_get(self):
        result = []
        for record in self:
            habitacion = f'{record.numhab}'
            result.append((record.id, habitacion))
        return result

class Factura(models.Model):
    _name = 'hotel.factura'
    _description = 'Modelo para gestionar facturas'

    id_factura = fields.Integer(string='Factura', required=True)
    fecha_facturacion = fields.Date(string='Fecha de facturacion de la factura', default=fields.Date.context_today, required=True)

    cliente_id = fields.Many2one('hotel.cliente', string='Cliente', required=True)
    dni_cliente = fields.Text(string='DNI', related='cliente_id.dnicli', required=True, readonly=True)
    nombre_cliente = fields.Text(string='nombre del cliente', related='cliente_id.nomcli', required=True)
    apellido_cliente = fields.Text(string='apellido del cliente', related='cliente_id.apecli', required=True)

    habitacion_id = fields.Many2one('hotel.habitacion', string='Habitacion', required=True)
    numero_hab = fields.Integer(string='Número de habitación', required=True, related='habitacion_id.numhab', index=True)
    tipo_hab = fields.Selection([
        ('individual', 'Individual'),
        ('matrimonio', 'Matrimonio')
    ], string='tipo', related='habitacion_id.tiphab', required=True)
    precio_hab = fields.Float(string='precio habitacion', related='habitacion_id.prechab', required=True)

    tipo_iva = fields.Selection([
        ('normal', 'IVA Normal (21%)'),
        ('simplificado', 'IVA Simplificado (10%)')
    ], string='Tipo de IVA', default='normal', required=True)

    @api.depends('precio_hab', 'tipo_iva')
    def calcular_precio_total(self):
        for factura in self:
            if factura.tipo_iva == 'normal':
                factura.precio_total = factura.precio_hab * 1.21
            elif factura.tipo_iva == 'simplificado':
                factura.precio_total = factura.precio_hab * 1.10
            else:
                factura.precio_total = factura.precio_hab

    precio_total = fields.Float(string='Precio Total', compute='calcular_precio_total', store=True)

    def name_get(self):
        result = []
        for record in self:
            name = f'Factura de {record.dni_cliente}'
            result.append((record.id, name))
        return result
